TO run the code please run the

`hw3.py file`
