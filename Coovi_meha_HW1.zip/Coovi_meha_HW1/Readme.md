This code is written in julia programming language.
To run the code you must have juia installed on your device. If not head to https://julialang.org/ to get it. I am using the V1.5.1

After proper set up.

rum the following commands in a terminal while cd into this directory:

`julia hw_1.jl bug_type -workspace_type` ----Where bug_type cam be bug1 or bug2 and workspace_type can be -w1 or -w2.

you can run the folling for help

`julia hw_1.jl help`
