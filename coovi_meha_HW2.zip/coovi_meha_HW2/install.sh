echo "\e[35mThis code is written python 3.8"

echo " \e[93mInstalling numpy"
pip install numpy
echo " \e[93mInstalling matplotlib"
pip install matplotlib
echo " \e[93mInstalling geopandas"

pip install geopandas
echo " \e[93mInstalling shapely"

pip install shapely