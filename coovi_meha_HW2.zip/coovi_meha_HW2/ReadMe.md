Before running this hw please run the bash script (install.sh) first to install the packages.

to run type `python hw2.py`
follow the instrution while runing the code

input 5 for exo5
input 7 for exo7

input 8 for exo8

check picture for pre-run output for exo8
